@extends('frontend.layout')

@section('content')
 
<div style="height: 300px;"></div>
 @endsection
